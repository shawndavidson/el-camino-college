//
//  balance.cpp
//  CS2-Project4
//
//  Created by Shawn Davidson on 10/24/21.
//

#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <istream>
#include <stack>

using namespace std;


// Matching pairs of symbols used in C++
// Symbol sequence must be paired in the order such that opening
// symbols have even indices and closing symbols have odd indices.
const string    symbolPairs             = "{}()[]";
const char      blockCommentSymbol      = 'c';

// Check if a character is an opening symbol such as {
// If so, return true. Otherwise, return false.
bool isOpeningBrace(int c)
{
    size_t pos = symbolPairs.find(c);
    
    return pos != std::string::npos && pos % 2 == 0;
}

// Check if a character is a closing symbol such as }
// If so, return true. Otherwise, return false.
bool isClosingBrace(int c, char& match)
{
    size_t pos = symbolPairs.find(c);
    
    if (pos != std::string::npos && pos % 2 != 0) {
        match = symbolPairs[pos-1];
        
        return true;
    }
    return false;
}

// Check if there is a an opening comment block "/*" at a specified position in a string
// If so, return true. Otherwise, return false.
bool opensBlockComment(const string& s, int pos) {
    return (pos + 1) < s.length() && s[pos] == '/' && s[pos+1] == '*';
}

// Check if there is a closing comment block "*/" at a specified position in a string
// If so, return true. Otherwise, return false.
bool closesBlockComment(const string& s, int pos) {
    return (pos + 1) < s.length() && s[pos] == '*' && s[pos+1] == '/';
}

// Check if there is an inline comment "//" at a specified position in a string
// If so, return true. Otherwise, return false.
bool opensInlineComment(const string& s, int pos) {
    return (pos + 1) < s.length() && s[pos] == '/' && s[pos+1] == '/';
}

// Check if there is an inline comment "//" at a specified position in a string
// If so, return true. Otherwise, return false.
bool extendsInlineComment(const string& s) {
    const size_t len = s.length();
    return len > 0 && s[len-1] == '\\';
}

// Report an unmatch single-character symbol error such as an unbalanced curly brace
void reportUnbalancedSymbol(char symbol, size_t lineNumber) {
    cout << "unmatched symbol " << symbol << " at line " << lineNumber << endl;
}

// Report an unmatch multi-character symbol error such as an unbalanced block comment
void reportUnbalancedSymbol(string multiCharSymbol, size_t lineNumber) {
    cout << "unmatched symbol " << multiCharSymbol << " at line " << lineNumber << endl;
}

// Report the occurance of a matched single-character symbol
void reportMatchedSymbol(char open, char close) {
    cout << "pair matching " << open << " and " << close << endl;
}

// Report the occurance of a matched multi-character symbol
void reportMatchedSymbol(string open, string close) {
    cout << "pair matching " << open << " and " << close << endl;
}

// Print a file with line numbers
void printFile(istream &dictfile)
{
    string s;
    
    // Read the file line by line
    for (int lineNumber = 1; !dictfile.eof(); lineNumber++) {
        getline(dictfile, s);
        
        cout << left << setw(4) << lineNumber << ": " << s << endl;
    }
    
    cout << endl << endl;
}

// Check if a C++ file is balanced. It is balanced if special symbols
// such as: {, (, [ are closed properly with matching symbols }, ), ].
// This also checks block and inline comments while ignoring the content
// that has been commented out.
bool balanceFile(istream &dictfile)
{
    struct Entry {
        char    symbol;
        size_t  lineNumber;
    };
    
    // Tracks the special symbols we encounter to check for balance
    stack<Entry> balanceStack;
        
    // Roll the file stream back to the beginning
    dictfile.clear();
    dictfile.seekg(0, dictfile.beg);

    string s;
    
    // Read the file line by line
    for (int lineNumber = 1; !dictfile.eof(); lineNumber++) {
        getline(dictfile, s);

        bool comment = false;
        
        // Parse a line character by character
        for (int i = 0; i < s.length(); i++) {
            char match;
            
            if (!comment && isOpeningBrace(s[i])) {
                // Push our symbol on the stack to track it
                Entry entry;
                
                entry.symbol        = s[i];
                entry.lineNumber    = lineNumber;
                
                balanceStack.push(entry);
            }else if (!comment && isClosingBrace(s[i], match)) {
                // Check the stack. If it's empty or the symbol on the top doesn't match
                // we're unbalanced.
                if (balanceStack.empty() || balanceStack.top().symbol != match) {
                    reportUnbalancedSymbol(s[i], lineNumber);
                    return false;
                }
                
                // Handle a matching symbol
                balanceStack.pop();
                reportMatchedSymbol(match, s[i]);
            }else if (opensBlockComment(s, i)) {
                // Track that we're in a comment so we can ignore its content
                comment = true;
                
                // Push a single-character symbol on the stack for
                // the sake of simplicity to track block comments
                // since /* is more than one character
                Entry entry;
                
                entry.symbol        = blockCommentSymbol;
                entry.lineNumber    = lineNumber;
                
                balanceStack.push(entry);
            }else if (closesBlockComment(s, i)) {
                // Track that we're out of our comment
                comment = false;
                
                // Check the stack. If it's empty or the symbol on the top doesn't match
                // we're unbalanced.
                if (balanceStack.empty() || balanceStack.top().symbol != blockCommentSymbol) {
                    reportUnbalancedSymbol("*/", lineNumber);
                    return false;
                }
                
                balanceStack.pop();
                reportMatchedSymbol("/*", "*/");
            }else if (opensInlineComment(s, i)) {
                // ignore the rest of the line
                continue;
            }
        }
    }
            
    // Check if there are any unmatched symbols left on the stack
    // that would indicate an unbalanced state
    if (!balanceStack.empty()) {
        // Dump everything except the first item on the stack so we
        // get the initial unbalanced symbol
        while (balanceStack.size() > 1)
            balanceStack.pop();

        // Report the first unbalanced symbol
        const Entry& entry = balanceStack.top();
        
        if (entry.symbol != blockCommentSymbol)
            reportUnbalancedSymbol(entry.symbol, entry.lineNumber);
        else
            reportUnbalancedSymbol("/*", entry.lineNumber);

        balanceStack.pop();
    
        return false;
    }
    
    return true;
}

