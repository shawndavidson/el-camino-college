//
//  anagram.cpp
//  Project 2
//
//  Created by Shawn Davidson on 9/27/21.
//

#include "anagram.hpp"
#include "tests.hpp"

#include <iostream>
#include <fstream>
#include <istream>
#include <string>

using namespace std;

const int MAXRESULTS   = 20;    // Max matches that can be found
const int MAXDICTWORDS = 30000; // Max words that can be read in

const int MAXWORDLENGTH     = 1000;

// Forward Declaration(s)
void printPermutionsRecursively(string prefix, string rest, string results[],
                                int& nResults, const string dict[], const int size);

int main()
{
    doBasicTests();
    
    cout << endl << endl;
    
    string results[MAXRESULTS];
    string dict[MAXDICTWORDS];
        
    ifstream dictfile;         // file containing the list of words
    int nwords;                // number of words read from dictionary
    string word;
    
    // TODO: must remove absolute path - copy words.txt to target location
    dictfile.open("/Users/sdavidson/XCodeProjects/Project 2/Project 2/words.txt");
    if (!dictfile) {
        cout << "File not found!" << endl;
        return (1);
    }
    
    nwords = loadDictionary(dictfile, dict);
    
    cout << "Please enter a string for an anagram: ";
    cin >> word;
    
    int numMatches = permuteRecur(word, dict, nwords, results);
    if (!numMatches)
        cout << "No matches found" << endl;
    else
        printRecur(results, numMatches);
}

int loopDictionaryWords(int i, int max, istream& dictfile, string dict[]) {
    if (i == max)
        return 0;
    
    char str[MAXWORDLENGTH];

    if (!dictfile.getline(str, MAXWORDLENGTH))
        return 0;
    
    dict[0] = str;
    
    return 1 + loopDictionaryWords(i+1, max, dictfile, dict + 1);
}

int loadDictionary(istream &dictfile, string dict[]) {
    return loopDictionaryWords(0, MAXDICTWORDS, dictfile, dict);
}

bool hasWord(string word, const string words[], const int size) {
    if (size == 0)
        return false;
    
    if (words[0] == word)
        return true;
    
    return hasWord(word, words + 1, size - 1);
}

void loopPermutations(int i, int max, string prefix, string rest, string results[],
                      int& nResults, const string dict[], const int size) {
    if (i == max || nResults == MAXRESULTS)
        return;
    
    string nextPrefix = prefix + rest[i];
    string nextRest   = rest.substr(0, i) + rest.substr(i+1);

    printPermutionsRecursively(nextPrefix, nextRest, results, nResults, dict, size);

    loopPermutations(i+1, max, prefix, rest, results, nResults, dict, size);
}

// Print the permutations of a word (using ONLY recursion)
void printPermutionsRecursively(string prefix, string rest, string results[],
                                int& nResults, const string dict[], const int size) {
    if (nResults == MAXRESULTS)
        return;
     
    if (rest.length() == 0) {
        // Save permutation to results, if it's NOT already in the array
        if (!hasWord(prefix, results, nResults) && hasWord(prefix, dict, size)) {
            results[nResults++] = prefix;
        }
    }else {
        loopPermutations(0, (int)rest.length(), prefix, rest, results, nResults, dict, size);
    }
}

int permuteRecur(string word, const string dict[], int size, string results[])
{
    int nResults = 0;

    printPermutionsRecursively("", word, results, nResults, dict, size);
    
    return nResults;
}

void printRecur(const string results[], int size)
{
    if (size == 0)
        return;
    
    cout << "Matching word " << results[0] << endl;
    
    printRecur(results + 1, size - 1);
}

