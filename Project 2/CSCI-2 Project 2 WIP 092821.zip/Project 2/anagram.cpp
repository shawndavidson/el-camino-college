//
//  anagram.cpp
//  Project 2
//
//  Created by Shawn Davidson on 9/27/21.
//

#include "anagram.hpp"

#include <iostream>
#include <fstream>
#include <istream>
#include <string>

using namespace std;

const int MAXRESULTS   = 20;    // Max matches that can be found
const int MAXDICTWORDS = 30000; // Max words that can be read in

const int MAXWORDLENGTH     = 1000;

// Forward Declaration(s)
void printPermutionsRecursively(string prefix, string rest,
                                string results[], int& nResults, int maxResults);

int main()
{
    string results[MAXRESULTS];
    string dict[MAXDICTWORDS];
        
    ifstream dictfile;         // file containing the list of words
    int nwords;                // number of words read from dictionary
    string word;
    
    // TODO: must remove absolute path - copy words.txt to target location
    dictfile.open("/Users/sdavidson/XCodeProjects/Project 2/Project 2/words.txt");
    if (!dictfile) {
        cout << "File not found!" << endl;
        return (1);
    }
    
    nwords = loadDictionary(dictfile, dict);
    
    cout << "Please enter a string for an anagram: ";
    cin >> word;
    
    int numMatches = permuteRecur(word, dict, nwords, results);
    if (!numMatches)
        cout << "No matches found" << endl;
    else
        printRecur(results, numMatches);
}

int loopDictionaryWords(int i, int max, istream& dictfile, string dict[]) {
    if (i == max)
        return 0;
    
    char str[MAXWORDLENGTH];

    if (!dictfile.getline(str, MAXWORDLENGTH))
        return 0;
    
    dict[0] = str;
    
    return 1 + loopDictionaryWords(i+1, max, dictfile, dict + 1);
}

int loadDictionary(istream &dictfile, string dict[]) {
//    char str[MAXWORDLENGTH];
    
    return loopDictionaryWords(0, MAXDICTWORDS, dictfile, dict);
    
//    if (!dictfile.getline(str, MAXWORDLENGTH) || str == ALWAYSLASTWORD)
//        return 0;
//
//    dict[0] = str;
//
//    return 1 + loadDictionary(dictfile, dict + 1);
}

// TODO: Remove maxResults since MAXRESULTS is a global variable
void loopPermutations(int i, int max, string prefix, string rest, string results[],
                      int& nResults, int maxResults) {
    if (i == max || nResults == maxResults)
        return;
    
    string nextPrefix = prefix + rest[i];
    string nextRest   = rest.substr(0, i) + rest.substr(i+1);

    printPermutionsRecursively(nextPrefix, nextRest, results, nResults, maxResults);

    loopPermutations(i+1, max, prefix, rest, results, nResults, maxResults);
}

// Print the permutations of a word (using ONLY recursion)
// TODO: Remove maxResults since MAXRESULTS is a global variable
void printPermutionsRecursively(string prefix, string rest, string results[],
                                int& nResults, int maxResults) {
    if (nResults == maxResults)
        return;
     
    if (rest.length() == 0) {
        // Save permutation to results
        results[nResults++] = prefix;
    }else {
        loopPermutations(0, (int)rest.length(), prefix, rest, results, nResults, maxResults);
    }
}

int permuteRecur(string word, const string dict[], int size, string results[])
{
    string  prefix;
    string  rest;
    int     nResults = 0;

    printPermutionsRecursively("", word, results, nResults, MAXRESULTS);
    
    return nResults;
}

void printRecur(const string results[], int size)
{
    if (size == 0)
        return;
    
    cout << results[0] << endl;
    
    printRecur(results + 1, size - 1);
}

