//
//  tests.hpp
//  Project 2
//
//  Created by Shawn Davidson on 9/27/21.
//

#ifndef tests_hpp
#define tests_hpp

#include <stdio.h>

void doBasicTests();

#endif /* tests_hpp */
