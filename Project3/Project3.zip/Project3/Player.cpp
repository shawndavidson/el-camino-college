//
//  Player.cpp
//  Project3
//
//  Created by Shawn Davidson on 10/4/21.
//

#include <iostream>
#include <algorithm> // new
#include <math.h> // new
#include "Player.hpp"
#include "Arena.hpp"
#include "globals.h"

using namespace std;

///////////////////////////////////////////////////////////////////////////
//  Player implementations
///////////////////////////////////////////////////////////////////////////

Player::Player(Arena* ap, int r, int c)
{
    if (ap == nullptr)
    {
        cout << "***** The player must be in some Arena!" << endl;
        exit(1);
    }
    if (r < 1  ||  r > ap->rows()  ||  c < 1  ||  c > ap->cols())
    {
        cout << "**** Player created with invalid coordinates (" << r
             << "," << c << ")!" << endl;
        exit(1);
    }
    m_arena = ap;
    m_row = r;
    m_col = c;
    m_age = 0;
    m_dead = false;
}

int Player::row() const
{
      // TODO: TRIVIAL:  Return what row the player is at.
      // Delete the following line and replace it with the correct code.
    return m_row;  // This implementation compiles, but is incorrect.
}

int Player::col() const
{
      // TODO: TRIVIAL:  Return what column the player is at.
      // Delete the following line and replace it with the correct code.
    return m_col;  // This implementation compiles, but is incorrect.
}

int Player::age() const
{
      // TODO:  TRIVIAL:  Return the player's age.
      // Delete the following line and replace it with the correct code.
    return m_age;  // This implementation compiles, but is incorrect.
}

string Player::takeComputerChosenTurn()
{
    // TODO:  Replace this implementation:
//        stand();
//        return "Stood";
    // Your replacement implementation should do something intelligent
    // and return a string that describes what happened.  When you've
    // decided what action to take, take it by calling move, shoot, or stand.
    // This function must return one of the following four strings:
    //     "Moved."
    //     "Shot and hit!"
    //     "Shot and missed!"
    //     "Stood."

    // Here's one possible strategy:
    //   If moving in some direction would put me in less immediate danger
    //     than standing, then move in that direction.
    //   else shoot in the direction of the nearest robot I can hit.

    // A more aggressive strategy is possible, where you hunt down robots.
    struct {
        int     row;
        int     col;
        double  danger;
    } danger[4];
    
    int leastDangerousDir = -1;
    
    for (int dir = UP; dir < RIGHT; dir++) {
        int r = m_row;
        int c = m_col;
        
        switch (dir)
        {
            case UP:
              // TODO:  Move the player up one row if possible.
              if (r > 1)
                  r--;
              break;
            case DOWN:
              if (r < m_arena->rows())
                  r++;
              break;
            case LEFT:
              if (c > 1)
                  c--;
              break;
            case RIGHT:
              // TODO:  Implement the other movements.
              if (c < m_arena->cols())
                  c++;
              break;
        }
        
        danger[dir] = { r, c, computeDanger(r, c) };
        
        if (leastDangerousDir == -1 || danger[dir].danger < danger[leastDangerousDir].danger) {
            leastDangerousDir = dir;
        }
    }
    
    if (computeDanger(m_row, m_col) < danger[leastDangerousDir].danger) {
        stand();
        return "Stood.";
    }
    
    // Try to shoot
    int dirToShoot = getDirectionOfNearestRobot();
    
    if (dirToShoot == -1) {
        move(leastDangerousDir);
        return "Moved.";
    }
    
    if (shoot(dirToShoot))
        return "Shot and hit!";

    return "Shot and missed!";
}

// Compute a metric for the danger level from this position
// by counting the number of robots within shooting range
double Player::computeDanger(int row, int col) const {
    double dangerLevel = 0.0;
    
    const int rowStart  = max(1, row - MAXSHOTLEN);
    const int rowEnd    = max(m_arena->rows(), row + MAXSHOTLEN);
    const int colStart  = max(1, col - MAXSHOTLEN);
    const int colEnd    = max(m_arena->cols(), col + MAXSHOTLEN);
    
    for (int r = rowStart; r < rowEnd;r++) {
        for (int c = colStart; c < colEnd; c++) {
            // Use pythagorean theorm to calculate the distance from the robot
            double distance = sqrt(pow(row-r, 2) + pow(col-c, 2));
            
            // Compute the danger level as the number of robots weighted inversly by their distance
            dangerLevel += m_arena->nRobotsAt(r, c) * (1.0/distance);
        }
    }
    
    return dangerLevel;
}

int Player::getDirectionOfNearestRobot() const {
    int nRobotsByDir[4];
    int dir = -1;
    
    // Iterate outward in concentric circles that represent distance to check if
    // there is a robot within shooting range position. In actuality, we only
    // check along the horizontal and vertical axis of our current player
    // because we can't shoot on a diagonal.
    for (int radius = 1; radius <= MAXSHOTLEN && dir == -1; radius++) {
        // Look up
        if (m_row - radius >= 1) {
            nRobotsByDir[UP] = m_arena->nRobotsAt(m_row - radius, m_col);
            if (nRobotsByDir[UP] > 0)
                dir = UP;
        }
        // Look down
        if (m_row + radius <= m_arena->rows()) {
            nRobotsByDir[DOWN] = m_arena->nRobotsAt(m_row + radius, m_col);
            if (nRobotsByDir[DOWN] > 0)
                dir = DOWN;
        }
        // Look left
        if (m_col - radius >= 1) {
            nRobotsByDir[LEFT] = m_arena->nRobotsAt(m_row, m_col - radius);
            if (nRobotsByDir[LEFT] > 0)
                dir = LEFT;
        }
        // Look right
        if (m_col + radius >= m_arena->cols()) {
            nRobotsByDir[RIGHT] = m_arena->nRobotsAt(m_row, m_col + radius);
            if (nRobotsByDir[RIGHT] > 0)
                dir = RIGHT;
        }
    }
    
    return dir;
}

void Player::stand()
{
    m_age++;
}

void Player::move(int dir)
{
    m_age++;
    switch (dir)
    {
        case UP:
          // TODO:  Move the player up one row if possible.
          if (m_row > 1)
              m_row--;
          break;
        case DOWN:
          if (m_row < m_arena->rows())
              m_row++;
          break;
        case LEFT:
          if (m_col > 1)
              m_col--;
          break;
        case RIGHT:
          // TODO:  Implement the other movements.
          if (m_col < m_arena->cols())
              m_col++;
          break;
    }
}

bool Player::shoot(int dir)
{
    m_age++;

    if (rand() % 3 == 0)  // miss with 1/3 probability
        return false;

      // TODO:  Damage the nearest robot in direction dir, returning
      // true if a robot is hit and damaged, false if not hit.
    switch(dir) {
        case UP: {
            int newRow = std::max(1, m_row - MAXSHOTLEN);
            
            for (int r = m_row; r >= newRow; r--) {
                if (m_arena->nRobotsAt(r, m_col) > 0) {
                    m_arena->damageRobotAt(r, m_col);
                    return true;
                }
            }
            break;
        }
        case DOWN: {
            int newRow = std::min(m_arena->rows(), m_row + MAXSHOTLEN);
            
            for (int r = m_row; r <= newRow; r++) {
                if (m_arena->nRobotsAt(r, m_col) > 0) {
                    m_arena->damageRobotAt(r, m_col);
                    return true;
                }
            }
            break;
        }
        case LEFT: {
            int newCol = std::max(1, m_col - MAXSHOTLEN);
            
            for (int c = m_col; c >= newCol; c--) {
                if (m_arena->nRobotsAt(m_row, c) > 0) {
                    m_arena->damageRobotAt(m_row, c);
                    return true;
                }
            }
            break;
        }
        case RIGHT: {
            int newCol = std::min(m_arena->cols(), m_col + MAXSHOTLEN);
            
            for (int c = m_col; c <= newCol; c++) {
                if (m_arena->nRobotsAt(m_row, c) > 0) {
                    m_arena->damageRobotAt(m_row, c);
                    return true;
                }
            }
            break;
        }
    }
    
    return false;  // This implementation compiles, but is incorrect.
}

bool Player::isDead() const
{
      // TODO:  TRIVIAL:  Return whether the player is dead.
    return m_dead;  // This implementation compiles, but is incorrect.
}

void Player::setDead()
{
    m_dead = true;
}

